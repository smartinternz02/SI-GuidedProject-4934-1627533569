Greetings,

Step-1 : First copy all the contents in a new folder.
Step-2 : Now inside the folder create a new folder name "data" where we will store the training data.
         I have already made the folder and trained some face data.
Step-3 : Now open the "Haarcascade Face Detection" file using jupyter notebook and run the program.
Step-4 : Then type the name of the person whose data you want to train and store.
Step-5 : Repeat step-1 and step-2 to train data for multiple human faces.
Step-6 : Now open the  "Face Classifier" file.
Step-7 : Place the person in front of web cam whose identify you want to recognize.
Step-8 : Now run the program and it will show the name of the person around his/her face with a bounding box.

Thank You

Harshit Johri(19BCE10292)
Rabindra Kumar(19BCE10033)
Kanhaiya Singh(19BCE10288)

